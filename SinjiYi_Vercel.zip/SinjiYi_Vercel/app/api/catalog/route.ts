import {getCatalog} from '@/lib/catalog';
export const runtime = 'nodejs';
export const maxDuration = 60;

export async function GET(request:Request) {
  const p=new URL(request.url).searchParams;
  const page=Number(p.get('page') || '1');
  if(!Number.isInteger(page)||page<1||page>500)return Response.json({error:'Invalid page'},{status:400});
  try {return Response.json(await getCatalog({q:p.get('q')?.trim(),genre:p.get('genre')||undefined,view:p.get('view')||undefined,sort:p.get('sort')||undefined,page}));}
  catch {return Response.json({error:'The catalog could not be loaded. Please try again.'},{status:502});}
}
