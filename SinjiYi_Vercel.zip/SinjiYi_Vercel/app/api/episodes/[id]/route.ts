import {getEpisodes} from '@/lib/catalog';
export const runtime = 'nodejs';
export const maxDuration = 60;

export async function GET(request:Request,context:{params:Promise<{id:string}>}) {
  const {id}=await context.params;const offset=Number(new URL(request.url).searchParams.get('offset')||0);
  if(!/^\d{1,8}$/.test(id)||!Number.isInteger(offset)||offset<0||offset>5000)return Response.json({error:'Invalid request'},{status:400});
  try{return Response.json(await getEpisodes(id,offset));}catch{return Response.json({error:'Episode details are temporarily unavailable.'},{status:502});}
}
