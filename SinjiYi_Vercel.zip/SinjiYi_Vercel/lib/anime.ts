import localAssets from '@/data/assets.json';
const assetMap = localAssets as Record<string,{poster?:string;cover?:string}>;
export type Anime = {
  id: string; title: string; originalTitle: string; synopsis: string;
  poster: string; cover: string; year: string; format: string; status: string;
  episodes: number | null; duration: number | null; score: string;
  trailerId: string; slug: string; ageRating: string; popularity: number;
};
export type Episode = { id: string; number: number; title: string; synopsis: string; thumbnail: string; };
export type WatchLink = { name: string; url: string; regions: string[] };
export type Detail = { anime: Anime; genres: string[]; episodes: Episode[]; links: WatchLink[]; hasMoreEpisodes: boolean; episodeError?: boolean; linkError?: boolean; cached?: boolean };
export type Catalog = { items: Anime[]; count: number; hasMore: boolean; cached?: boolean; notice?: string };

type Resource = { id: string; attributes: Record<string, any>; relationships?: Record<string, any> };
export function cleanText(value: unknown): string {
  return typeof value === 'string' ? value.replace(/<[^>]*>/g, '').replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&#039;/g, "'").trim() : '';
}
export function safeUrl(value: unknown): string {
  if (typeof value !== 'string') return '';
  try { const u = new URL(value); return u.protocol === 'https:' ? u.href : ''; } catch { return ''; }
}
export function normalizeAnime(item: Resource): Anime {
  const a = item.attributes;
  return { id: item.id, title: cleanText(a.titles?.en || a.canonicalTitle || a.titles?.en_jp), originalTitle: cleanText(a.titles?.ja_jp || a.titles?.en_jp || ''),
    synopsis: cleanText(a.synopsis || a.description), poster: assetMap[item.id]?.poster || safeUrl(a.posterImage?.large || a.posterImage?.original || a.posterImage?.medium),
    cover: assetMap[item.id]?.cover || safeUrl(a.coverImage?.original || a.coverImage?.large), year: a.startDate?.slice(0,4) || '', format: a.subtype || 'TV', status: a.status || '',
    episodes: a.episodeCount || null, duration: a.episodeLength || null, score: a.averageRating ? (Number(a.averageRating)/10).toFixed(1) : '',
    trailerId: /^[\w-]{11}$/.test(a.youtubeVideoId || '') ? a.youtubeVideoId : '', slug: a.slug || '', ageRating: a.ageRating || '', popularity: a.popularityRank || 99999 };
}
export function normalizeEpisode(item: Resource): Episode {
  const a = item.attributes;
  return {id:item.id,number:a.number,title:cleanText(a.titles?.en || a.canonicalTitle || a.titles?.en_jp || `Episode ${a.number}`),synopsis:cleanText(a.synopsis),thumbnail:safeUrl(a.thumbnail?.original || a.thumbnail?.large)};
}
export const genreOptions = ['All genres','Action','Adventure','Comedy','Drama','Fantasy','Romance','Sci-Fi','Slice of Life'];
export function genreSlug(genre: string) { return genre === 'Sci-Fi' ? 'science-fiction' : genre.toLowerCase().replaceAll(' ', '-'); }
