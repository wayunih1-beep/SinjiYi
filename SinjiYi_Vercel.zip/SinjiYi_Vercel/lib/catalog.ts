import popularSnapshot from '@/data/popular.json';
import featuredSnapshot from '@/data/featured.json';
import airingSnapshot from '@/data/airing.json';
import { Anime, Catalog, Detail, Episode, WatchLink, cleanText, genreSlug, normalizeAnime, normalizeEpisode, safeUrl } from './anime';

export const popular = popularSnapshot.data.filter(x => x.attributes.ageRating !== 'R18').map(normalizeAnime);
export const featured = normalizeAnime(featuredSnapshot.data[0]);
export const airing = airingSnapshot.data.filter(x => x.attributes.ageRating !== 'R18').map(normalizeAnime);
const allSaved = Array.from(new Map([featured,...popular,...airing].map(a=>[a.id,a])).values());
const memory = new Map<string,{value:any; expires:number}>();
export async function kitsu(path: string, params: Record<string,string> = {}) {
  const query = new URLSearchParams(params).toString();
  const url = `https://kitsu.io/api/edge/${path}${query ? '?'+query : ''}`;
  const cached = memory.get(url);
  if(cached && cached.expires > Date.now()) return cached.value;
  const r = await fetch(url,{headers:{Accept:'application/vnd.api+json','User-Agent':'SinjiYi/1.0'},signal:AbortSignal.timeout(18000)});
  if(!r.ok) { console.warn('Kitsu response',r.status,path); throw new Error(`Catalog unavailable (${r.status})`); }
  const value = await r.json() as any;
  if(!value || value.errors || value.data === undefined) throw new Error('Invalid catalog response');
  if(memory.size>150) memory.delete(memory.keys().next().value!);
  memory.set(url,{value,expires:Date.now()+5*60_000});
  return value;
}
export async function getCatalog(query: {q?:string; genre?:string; view?:string; sort?:string; page?:number}):Promise<Catalog> {
  const page = Math.max(1,Math.min(500,query.page || 1));
  const params: Record<string,string> = {'page[limit]':'20','page[offset]':String((page-1)*20),sort:query.sort==='rating'?'-averageRating':'popularityRank'};
  if(query.q)params['filter[text]']=query.q.slice(0,100);
  if(query.genre && query.genre!=='All genres')params['filter[categories]']=genreSlug(query.genre);
  if(query.view==='series')params['filter[subtype]']='TV';
  if(query.view==='movies')params['filter[subtype]']='movie';
  if(query.view==='airing')params['filter[status]']='current';
  try {
    const result=await kitsu('anime',params);
    return {items:result.data.filter((x:any)=>x.attributes.ageRating!=='R18').map(normalizeAnime),count:result.meta?.count || 0,hasMore:!!result.links?.next};
  } catch (error) {
    console.warn('Catalog fetch failed',String(error));
    // Only use genuine records, and label the reduced/offline result set explicitly.
    let records=query.view==='airing'?airing:allSaved;
    if(query.q)records=records.filter(a=>`${a.title} ${a.originalTitle} ${a.synopsis}`.toLowerCase().includes(query.q!.toLowerCase()));
    if(query.view==='movies')records=records.filter(a=>a.format.toLowerCase()==='movie');
    if(query.view==='series')records=records.filter(a=>a.format.toLowerCase()==='tv');
    if(query.genre && query.genre!=='All genres')throw new Error('Genre results are temporarily unavailable. Please try again.');
    if(query.sort==='rating')records=[...records].sort((a,b)=>Number(b.score)-Number(a.score));
    return {items:records.slice((page-1)*20,page*20),count:records.length,hasMore:records.length>page*20,cached:true,notice:'The live catalog is temporarily unavailable. Showing saved catalog results.'};
  }
}
export async function getEpisodes(id:string,offset=0):Promise<{episodes:Episode[];hasMore:boolean}> {
  const r=await kitsu(`anime/${id}/episodes`,{'page[limit]':'20','page[offset]':String(offset),'sort':'number'});
  return {episodes:r.data.map(normalizeEpisode),hasMore:!!r.links?.next};
}
export async function getDetail(id:string):Promise<Detail> {
  let cached=false;let anime:Anime;
  try { const r=await kitsu(`anime/${id}`); if(r.data.attributes.ageRating==='R18')throw new Error('Unavailable title');anime=normalizeAnime(r.data); }
  catch { const saved=allSaved.find(a=>a.id===id);if(!saved)throw new Error('This anime could not be loaded. Please try again.');anime=saved;cached=true; }
  const [categoryResult,episodeResult,linkResult]=await Promise.allSettled([
    kitsu(`anime/${id}/categories`,{'page[limit]':'30'}),
    getEpisodes(id),
    kitsu(`anime/${id}/streaming-links`,{include:'streamer'}),
  ]);
  let links:WatchLink[]=[];
  if(linkResult.status==='fulfilled'){
    const providers=linkResult.value.included || [];
    links=linkResult.value.data.map((l:any)=>{
      const streamer=providers.find((x:any)=>x.id===l.relationships?.streamer?.data?.id && x.type==='streamers');
      const url=safeUrl(l.attributes?.url);
      return {name:cleanText(streamer?.attributes?.siteName || streamer?.attributes?.name || (url ? new URL(url).hostname.replace(/^www\./,'') : '')),url,regions:l.attributes?.subs || []};
    }).filter((l:WatchLink)=>l.url && l.name);
  }
  return {anime,genres:categoryResult.status==='fulfilled'?categoryResult.value.data.map((c:any)=>cleanText(c.attributes.title)).slice(0,8):[],
    episodes:episodeResult.status==='fulfilled'?episodeResult.value.episodes:[],hasMoreEpisodes:episodeResult.status==='fulfilled'?episodeResult.value.hasMore:false,
    links,cached,episodeError:episodeResult.status==='rejected',linkError:linkResult.status==='rejected'};
}
