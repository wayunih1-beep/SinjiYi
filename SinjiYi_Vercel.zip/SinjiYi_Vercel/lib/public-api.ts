import { Catalog, Detail, Episode, WatchLink, cleanText, genreSlug, normalizeAnime, normalizeEpisode, safeUrl } from './anime';

// Kitsu exposes a public, CORS-enabled API. Direct requests keep the catalog
// available even when a preview/server network cannot reach the provider.
async function request(path:string,params:Record<string,string>={},signal?:AbortSignal){
  const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),12000);
  const abort=()=>controller.abort();signal?.addEventListener('abort',abort,{once:true});
  if(signal?.aborted)controller.abort();
  try{
    const qs=new URLSearchParams(params);
    const response=await fetch(`https://kitsu.io/api/edge/${path}${qs.size?'?'+qs:''}`,{headers:{Accept:'application/vnd.api+json'},signal:controller.signal});
    if(!response.ok)throw new Error('The catalog is temporarily unavailable.');
    const data=await response.json() as any;if(data.errors||data.data===undefined)throw new Error('Invalid catalog response');return data;
  }finally{clearTimeout(timeout);signal?.removeEventListener('abort',abort);}
}
export async function publicCatalog(p:URLSearchParams,signal?:AbortSignal):Promise<Catalog>{
  const page=Math.max(1,Number(p.get('page')||1));
  const params:Record<string,string>={'page[limit]':'20','page[offset]':String((page-1)*20),sort:p.get('sort')==='rating'?'-averageRating':'popularityRank'};
  if(p.get('q'))params['filter[text]']=p.get('q')!.slice(0,100);
  if(p.get('genre')&&p.get('genre')!=='All genres')params['filter[categories]']=genreSlug(p.get('genre')!);
  if(p.get('view')==='series')params['filter[subtype]']='TV';
  if(p.get('view')==='movies')params['filter[subtype]']='movie';
  if(p.get('view')==='airing')params['filter[status]']='current';
  const result=await request('anime',params,signal);
  return {items:result.data.filter((x:any)=>x.attributes.ageRating!=='R18').map(normalizeAnime),count:result.meta?.count||0,hasMore:!!result.links?.next};
}
export async function publicEpisodes(id:string,offset=0,signal?:AbortSignal):Promise<{episodes:Episode[];hasMore:boolean}>{
  const r=await request(`anime/${id}/episodes`,{'page[limit]':'20','page[offset]':String(offset),sort:'number'},signal);
  return {episodes:r.data.map(normalizeEpisode),hasMore:!!r.links?.next};
}
export async function publicDetail(id:string,signal?:AbortSignal):Promise<Detail>{
  const r=await request(`anime/${id}`,{include:'categories,streamingLinks.streamer'},signal);
  if(r.data.attributes.ageRating==='R18')throw new Error('This title is not available.');
  const included=r.included||[];const streamers=included.filter((x:any)=>x.type==='streamers');
  const links:WatchLink[]=included.filter((x:any)=>x.type==='streamingLinks').map((l:any)=>{
    const provider=streamers.find((x:any)=>x.id===l.relationships?.streamer?.data?.id);const url=safeUrl(l.attributes.url);
    return {name:cleanText(provider?.attributes.siteName||(url?new URL(url).hostname.replace(/^www\./,''):'')),url,regions:[]};
  }).filter((l:WatchLink)=>l.url);
  let episodes:Episode[]=[];let hasMoreEpisodes=false;let episodeError=false;
  try{const e=await publicEpisodes(id,0,signal);episodes=e.episodes;hasMoreEpisodes=e.hasMore;}catch{if(signal?.aborted)throw new DOMException('Aborted','AbortError');episodeError=true;}
  return {anime:normalizeAnime(r.data),genres:included.filter((x:any)=>x.type==='categories').map((x:any)=>cleanText(x.attributes.title)).slice(0,8),links,episodes,hasMoreEpisodes,episodeError};
}
export async function publicRequest(url:string,signal?:AbortSignal):Promise<unknown>{
  const u=new URL(url,'https://sinjiyi.local');
  if(u.pathname==='/api/catalog')return publicCatalog(u.searchParams,signal);
  const detail=u.pathname.match(/^\/api\/anime\/(\d+)$/);if(detail)return publicDetail(detail[1],signal);
  const episodes=u.pathname.match(/^\/api\/episodes\/(\d+)$/);if(episodes)return publicEpisodes(episodes[1],Number(u.searchParams.get('offset')||0),signal);
  throw new Error('Unknown API operation');
}
